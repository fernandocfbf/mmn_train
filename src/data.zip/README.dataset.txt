# MMN > 2022-11-08 9:11pm
https://universe.roboflow.com/fernandocfbf-al-insper-edu-br/mmn

Provided by a Roboflow user
License: CC BY 4.0

